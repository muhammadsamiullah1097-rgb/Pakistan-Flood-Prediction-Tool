# Pakistan Flood Early-Warning & Prediction System
### Python + ML + NLP, driven entirely by free, public, actively-maintained APIs

This project estimates **when, where, why, and how severely** flooding could occur
across every province, division, district and major city of Pakistan
(Punjab, Sindh, Khyber Pakhtunkhwa, Balochistan, Gilgit-Baltistan, Azad Jammu &
Kashmir, and Islamabad Capital Territory).

It is built to be a **decision-support early-warning tool**, not a replacement
for the Pakistan Meteorological Department (PMD), NDMA, PDMAs, WAPDA/IRSA, or
FFD (Flood Forecasting Division). Always follow official warnings first.

---

## 1. Why these APIs (all free, public, actively maintained, no fake data)

| # | API | What it gives | Why chosen |
|---|-----|----------------|------------|
| 1 | **Open-Meteo Weather Forecast API** (`api.open-meteo.com`) | Hourly/daily rainfall, temperature, wind, soil moisture forecast up to 16 days, any lat/lon on Earth | 100% free, no key, no rate-limit for reasonable use, updated multiple times a day |
| 2 | **Open-Meteo Historical Weather / Archive API** (`archive-api.open-meteo.com`) | ERA5 reanalysis rainfall & weather since 1940 | Real historical ground-truth for training the ML model, no key |
| 3 | **Open-Meteo Flood API** (`flood-api.open-meteo.com`) | Daily **river discharge** (m³/s) for any river coordinate, from the **Global Flood Awareness System (GloFAS)** — the same model European flood agencies use — historical since 1984 + forecast up to 210 days, with ensemble uncertainty (min/mean/max/p25/p75) | This is the single most important data source: it converts "how much rain" into "how much water is actually moving through the river," which is what actually causes river floods |
| 4 | **GDACS – Global Disaster Alert and Coordination System** (`gdacs.org`, UN + European Commission JRC) | Live, verified red/orange/green alerts for floods, cyclones, and other hazards worldwide, with country, coordinates, severity, and duration | Free public GeoRSS/JSON feed, verified by an intergovernmental body, used as a live "is something already declared" cross-check |
| 5 | **ReliefWeb API** (`api.reliefweb.int`, run by **UN OCHA**) | Verified situation reports, disaster declarations and humanitarian updates, searchable by country/keyword, archive back to the 1980s | Free, JSON, no key (only an `appname` identifier), gives the NLP layer real verified news text instead of scraping random sites |
| 6 | **NASA POWER API** (`power.larc.nasa.gov`) | Daily soil-moisture wetness fraction (root-zone & surface), solar/thermal data | Free, no key, NASA-verified; soil saturation is a critical precursor — the same rainfall causes far worse flooding on already-saturated ground |

All six are free forever for this kind of use, require no paid key, and are
updated continuously (daily-to-hourly), which satisfies the "highly
active + free + public + verified + huge historical data" requirement.

**Deliberately NOT used:** scraped/unofficial "news APIs" with no editorial
verification, and any paid API — because you asked for verified + free.

---

## 2. What was missing in a "basic" version of this idea (the gaps this build fixes)

You said you knew things were missing — here is the honest list:

1. **Rainfall ≠ Flood.** A model that only looks at rainfall forecasts is
   guessing. Real flood risk needs **river discharge** (GloFAS), because a
   flood in Sindh is very often caused by water released/arriving from
   Punjab/KP days earlier, not local rain. → Fixed with the Flood API.
2. **No soil-moisture / antecedent condition data.** Same rainfall on dry vs
   saturated soil gives very different outcomes. → Fixed with NASA POWER.
3. **No live cross-check against real declared disasters.** A model can say
   "high risk" while reality has already moved on. → Fixed with GDACS + ReliefWeb.
4. **No cause attribution ("why").** Most flood tools output a number, not a
   reason. This system tags each risk with a human-readable cause: monsoon
   rainfall, upstream river surge, glacial lake outburst flood (GLOF) risk in
   the north, urban drainage failure, or coastal/cyclone storm surge.
5. **No full administrative coverage.** Most public dashboards only cover
   2022-style headline provinces. This one has a structured gazetteer of
   provinces → divisions → districts → cities, tagged with river proximity,
   historical flood exposure, and terrain type (riverine / hill-torrent /
   glacial / coastal / urban).
6. **No seasonality/monsoon-phase awareness.** Risk changes drastically by
   month (pre-monsoon dust storms → monsoon peak July–Aug → post-monsoon
   western disturbances/glacial melt tail). The feature engineering encodes this.
7. **No demography/damage-context layer.** A "70% risk" means little without
   knowing who and what is exposed. Report generator attaches population
   exposure, historical damage patterns, and vulnerable-group notes per region.

---

## 3. Architecture

```
pakistan_flood_prediction/
├── config.py                    # thresholds, monsoon calendar, API base urls
├── data/
│   └── pakistan_regions.py      # gazetteer: province→division→district→city, lat/lon, river, terrain, pop.
├── ingestion/
│   ├── weather_client.py        # Open-Meteo forecast + historical rainfall/soil
│   ├── flood_client.py          # Open-Meteo Flood API (GloFAS river discharge)
│   ├── soil_moisture_client.py  # NASA POWER root-zone soil wetness
│   ├── gdacs_client.py          # live GDACS flood alerts, filtered to Pakistan
│   └── reliefweb_client.py      # verified UN OCHA disaster reports/sitreps
├── nlp/
│   └── news_analyzer.py         # rule+TF-IDF based severity/location/cause extraction from ReliefWeb+GDACS text
├── ml/
│   ├── feature_engineering.py   # builds the feature vector per region per day
│   └── risk_model.py            # trains + runs GloFAS-discharge-threshold-labelled classifier
├── reports/
│   └── report_generator.py      # builds the final why/when/how/how-much report (JSON + Markdown)
└── main.py                       # orchestrates everything end-to-end
```

### How the ML actually works (no invented labels)
Instead of pretending we have a labelled "flood/no-flood" dataset (one does not
freely exist at district level for Pakistan), the model creates its **own real
ground truth** from the Open-Meteo Flood API's own multi-decade discharge
history: a day is labelled a **high-flow event** if discharge exceeds the
location's own historical 90th percentile. A Gradient Boosting classifier then
learns to predict the probability of that event 1–10 days ahead from rainfall,
soil moisture, upstream discharge trend, and seasonal features. This is the
same "threshold exceedance" logic real hydrological early-warning centres use
— it is honest about being a **probabilistic risk score**, not a certainty.

---

## 4. Running it

```bash
cd pakistan_flood_prediction
pip install -r requirements.txt
python main.py --scope all            # every province/division/district/city
python main.py --scope province --name Sindh
python main.py --scope city --name Multan
```

Output: `output/national_flood_risk_report.md` and `.json`, plus one file per
region under `output/regions/`.

### Important — network note
This code needs outbound internet access to `open-meteo.com`,
`flood-api.open-meteo.com`, `power.larc.nasa.gov`, `gdacs.org`, and
`api.reliefweb.int`. Run it on your own machine/server/Colab — a sandboxed
environment that only allows package-manager domains (like the one this file
was authored in) cannot reach those hosts, so this project could be written
and reviewed here but not live-executed here. Everything is standard
`requests`-based Python, so it will run anywhere with normal internet access.

---

## 5. Honesty / limitations (please read)

- This is **not** a substitute for PMD/NDMA/FFD/WAPDA official warnings —
  always follow them first; they have ground gauges, radar, and dam-release
  authority data this system cannot access.
- GloFAS discharge at 5 km resolution can misidentify the nearest river
  channel in flat deltaic areas (e.g., parts of Sindh) — coordinates were
  chosen on/near real river channels, but you should sanity-check against the
  GloFAS map if using this operationally.
- Rain/discharge forecasts beyond ~10 days are genuinely uncertain everywhere
  in the world, including in this model — the report labels longer-range
  outlooks as "indicative" not "confirmed."
- Glacial Lake Outburst Floods (GLOFs) in Gilgit-Baltistan/Chitral are flagged
  as an elevated-risk *category* based on season+location; they are inherently
  hard to time-predict with weather data alone because they can be triggered
  by sudden ice-dam failure, not just rainfall.
- City/district coordinates in the gazetteer are approximate representative
  points, not official boundary files — good enough for weather/discharge
  queries, not for legal/administrative use.
