"""
Lightweight, dependency-safe NLP layer for verified flood news/reports
(from ReliefWeb + GDACS).

Design choice: rather than depending on a large downloaded language model
(unreliable in restricted/offline environments and overkill for this
job), this module uses:
  1. Gazetteer-based location matching against our own Pakistan region list
     (precise for a known, closed set of place names -- more reliable here
     than generic NER, which often mis-tags South Asian place names).
  2. Keyword/lexicon-based severity and cause scoring (transparent and
     auditable -- every score can be traced back to which words fired).
  3. TF-IDF (scikit-learn) to surface the most distinctive terms across a
     batch of reports, for the national-level "what is the news actually
     emphasising right now" summary.

This is intentionally simple and explainable rather than a black box --
appropriate for a decision-support tool where "why did it say that" matters.
"""
import re
from collections import defaultdict, Counter

from sklearn.feature_extraction.text import TfidfVectorizer

from data.pakistan_regions import PAKISTAN_REGIONS

SEVERITY_LEXICON = {
    # word/phrase -> severity points
    "dead": 5, "died": 5, "killed": 5, "death toll": 6, "fatalities": 5,
    "missing": 4, "injured": 3, "displaced": 4, "evacuat": 3, "rescue": 3,
    "destroyed": 4, "damaged": 2, "submerged": 4, "inundated": 4,
    "emergency": 3, "declared calamity": 5, "collapsed": 3, "breach": 4,
    "washed away": 4, "cut off": 3, "isolated": 3, "landslide": 3,
    "flash flood": 4, "cloudburst": 4, "glacial lake outburst": 5, "glof": 5,
    "embankment": 3, "spillway": 3, "warning": 2, "alert": 2, "red alert": 5,
    "orange alert": 3,
}

CAUSE_KEYWORDS = {
    "monsoon rainfall": ["monsoon", "heavy rain", "torrential rain", "rainfall"],
    "upstream river surge": ["upstream", "barrage", "river swell", "water level rising", "discharge"],
    "glacial melt / GLOF": ["glacial", "glacier", "glof", "snowmelt", "ice dam"],
    "urban drainage failure": ["drainage", "urban flooding", "sewerage", "storm drain"],
    "coastal storm / cyclone": ["cyclone", "storm surge", "arabian sea", "depression", "coastal"],
    "hill torrent / flash flood": ["hill torrent", "flash flood", "nullah", "cloudburst"],
    "dam/barrage release": ["barrage release", "dam release", "spillway", "reservoir"],
}

# Build a lookup of city/district names for gazetteer matching (longest first
# so "Dera Ghazi Khan" matches before "Dera")
_PLACE_NAMES = sorted(
    {r["city"] for r in PAKISTAN_REGIONS} | {r["district"] for r in PAKISTAN_REGIONS} | {r["province"] for r in PAKISTAN_REGIONS},
    key=len, reverse=True,
)


def _extract_places(text: str) -> list:
    text_l = text.lower()
    found = []
    for name in _PLACE_NAMES:
        if name.lower() in text_l:
            found.append(name)
    return found


def _severity_score(text: str) -> int:
    text_l = text.lower()
    score = 0
    for phrase, points in SEVERITY_LEXICON.items():
        occurrences = len(re.findall(re.escape(phrase), text_l))
        score += occurrences * points
    return score


def _detect_causes(text: str) -> list:
    text_l = text.lower()
    causes = []
    for cause, keywords in CAUSE_KEYWORDS.items():
        if any(k in text_l for k in keywords):
            causes.append(cause)
    return causes


def analyze_reports(reports: list) -> dict:
    """
    reports: list of dicts with at least 'title' and 'body' (ReliefWeb
             shape) or 'title' and 'summary' (GDACS shape).
    Returns a structured signal: per-place mention/severity, national top
    causes, and the most salient distinctive terms via TF-IDF.
    """
    place_mentions = defaultdict(int)
    place_severity = defaultdict(int)
    place_causes = defaultdict(Counter)
    place_latest_headline = {}
    corpus = []

    for r in reports:
        text = " ".join([
            r.get("title", "") or "",
            r.get("body", "") or r.get("summary", "") or "",
        ])
        corpus.append(text)
        places = _extract_places(text)
        sev = _severity_score(text)
        causes = _detect_causes(text)
        for p in places:
            place_mentions[p] += 1
            place_severity[p] += sev
            for c in causes:
                place_causes[p][c] += 1
            if p not in place_latest_headline:
                place_latest_headline[p] = r.get("title")

    top_terms = []
    if corpus:
        try:
            vectorizer = TfidfVectorizer(max_features=25, stop_words="english", ngram_range=(1, 2))
            matrix = vectorizer.fit_transform(corpus)
            scores = matrix.sum(axis=0).A1
            terms = vectorizer.get_feature_names_out()
            top_terms = sorted(zip(terms, scores), key=lambda x: -x[1])[:15]
            top_terms = [t for t, s in top_terms]
        except ValueError:
            top_terms = []

    return {
        "n_reports_analyzed": len(reports),
        "place_signal": {
            p: {
                "mentions": place_mentions[p],
                "severity_score": place_severity[p],
                "top_causes": [c for c, _ in place_causes[p].most_common(3)],
                "latest_headline": place_latest_headline.get(p),
            }
            for p in place_mentions
        },
        "national_top_terms": top_terms,
    }


def news_signal_for_place(analysis: dict, place_name: str) -> dict:
    """Convenience accessor used by the report generator per-region."""
    return analysis.get("place_signal", {}).get(
        place_name,
        {"mentions": 0, "severity_score": 0, "top_causes": [], "latest_headline": None},
    )
