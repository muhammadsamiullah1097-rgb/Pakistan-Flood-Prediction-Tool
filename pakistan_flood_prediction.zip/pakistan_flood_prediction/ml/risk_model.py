"""
The prediction core.

Two layers, deliberately kept separate and both inspectable:

1. LEARNED layer (GradientBoostingClassifier, scikit-learn):
   Trained per-location on that location's OWN multi-decade rainfall +
   GloFAS discharge history. The label is not invented -- it is "did
   discharge exceed this river's own historical 90th percentile the next
   day," which is a standard hydrological high-flow/flood-stage proxy.
   Predicts P(high-flow event) from rainfall + soil moisture + seasonality.

2. RULE layer (transparent, human-auditable):
   Adjusts/annotates the learned probability using live corroborating
   evidence (GDACS active alert, verified news severity) and produces the
   human-readable WHY (cause attribution) and HOW MUCH (severity tier),
   because a bare probability number does not answer "why" or "how bad."

Final output per region combines both, clearly labelling which parts came
from the trained model vs. the rule layer, so nothing is a black box.
"""
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split

from config import (
    RAINFALL_MODERATE_MM, RAINFALL_HEAVY_MM, RAINFALL_VERY_HEAVY_MM, RAINFALL_EXTREME_MM,
    SOIL_SATURATION_THRESHOLD, TERRAIN_MECHANISMS,
)

FEATURE_COLUMNS = ["rain_lag1", "rain_lag2", "rain_3d_sum", "rain_7d_sum", "month"]


def train_location_model(training_df):
    """
    Trains one lightweight GradientBoostingClassifier for a single
    location's historical record. Returns (model, metrics) or
    (None, reason) if there isn't enough data / label variety
    (e.g. a river that essentially never crosses its own high-flow
    threshold in the sample, which does happen for smaller seasonal
    streams -- handled gracefully rather than forced).
    """
    df = training_df.dropna(subset=FEATURE_COLUMNS + ["label_high_flow_next_day"])
    if len(df) < 200 or df["label_high_flow_next_day"].nunique() < 2:
        return None, "insufficient_history_or_no_label_variance"

    X = df[FEATURE_COLUMNS]
    y = df["label_high_flow_next_day"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    model = GradientBoostingClassifier(
        n_estimators=150, max_depth=3, learning_rate=0.08, random_state=42
    )
    model.fit(X_train, y_train)
    test_accuracy = model.score(X_test, y_test)

    return model, {"test_accuracy": test_accuracy, "n_train": len(X_train), "n_test": len(X_test)}


def predict_probability(model, feature_row: dict) -> float:
    x = pd.DataFrame([{c: feature_row.get(c, 0) or 0 for c in FEATURE_COLUMNS}], columns=FEATURE_COLUMNS)
    proba = model.predict_proba(x)[0]
    # class 1 = high-flow event
    classes = list(model.classes_)
    return float(proba[classes.index(1)]) if 1 in classes else 0.0


@dataclass
class RiskAssessment:
    region: dict
    ml_probability: float | None       # None if model could not be trained (fallback used)
    fallback_used: bool
    risk_tier: str                     # LOW / MODERATE / HIGH / SEVERE
    risk_score_0_100: float
    likely_causes: list = field(default_factory=list)
    predicted_window_days: tuple = (1, 7)
    rationale: list = field(default_factory=list)


def _rule_based_probability(feature_row: dict) -> float:
    """
    Fallback when a per-location ML model can't be trained (e.g. brand-new
    location, missing history). Transparent weighted-threshold heuristic
    used by many operational early-warning systems as a baseline.
    """
    score = 0.0
    rain7 = feature_row.get("rain_next_7d_mm") or 0
    rain_max = feature_row.get("rain_max_day_mm") or 0
    soil = feature_row.get("soil_root_wetness") or 0.4
    disc_ratio = feature_row.get("discharge_ratio_now") or 0.3
    seasonal_w = feature_row.get("seasonal_weight") or 0.2

    if rain_max >= RAINFALL_EXTREME_MM:
        score += 0.35
    elif rain_max >= RAINFALL_VERY_HEAVY_MM:
        score += 0.25
    elif rain_max >= RAINFALL_HEAVY_MM:
        score += 0.15
    elif rain_max >= RAINFALL_MODERATE_MM:
        score += 0.07

    score += min(rain7 / 400.0, 0.25)                       # cumulative rainfall contribution
    score += 0.15 if soil >= SOIL_SATURATION_THRESHOLD else 0.0
    score += min(max(disc_ratio - 0.6, 0) * 0.4, 0.25)       # already-elevated river contribution
    score *= (0.5 + 0.5 * seasonal_w)                        # seasonal dampening/amplification

    return float(min(max(score, 0.0), 1.0))


def _cause_attribution(feature_row: dict, region: dict, news_top_causes: list) -> list:
    causes = []
    terrain = region.get("terrain", "arid_plain")
    causes.append(TERRAIN_MECHANISMS.get(terrain, "general flooding risk"))

    if (feature_row.get("rain_max_day_mm") or 0) >= RAINFALL_HEAVY_MM:
        causes.append("heavy-to-extreme monsoon/rain-spell rainfall in the forecast window")
    if (feature_row.get("discharge_ratio_now") or 0) >= 0.8:
        causes.append("river already running close to/above its own historical high-flow threshold (upstream contribution likely)")
    if (feature_row.get("soil_root_wetness") or 0) >= SOIL_SATURATION_THRESHOLD:
        causes.append("ground already saturated from prior rainfall, raising runoff for any new rain")
    if feature_row.get("gdacs_active_alert"):
        causes.append("an internationally verified GDACS flood alert is currently active for Pakistan")
    for c in news_top_causes:
        if c not in causes:
            causes.append(f"verified news reporting indicates: {c}")
    return causes


def _risk_tier(probability: float) -> str:
    if probability >= 0.75:
        return "SEVERE"
    if probability >= 0.5:
        return "HIGH"
    if probability >= 0.25:
        return "MODERATE"
    return "LOW"


def assess_region(region: dict, feature_row: dict, trained_model, news_signal: dict) -> RiskAssessment:
    fallback_used = trained_model is None
    if trained_model is not None:
        ml_probability = predict_probability(trained_model, feature_row)
    else:
        ml_probability = None

    rule_probability = _rule_based_probability(feature_row)

    if ml_probability is not None:
        # Blend: trust the learned, river-specific model more, but let live
        # verified corroboration (news/GDACS) pull it further only within a
        # capped range so no single noisy headline can dominate the score.
        blended = 0.7 * ml_probability + 0.3 * rule_probability
    else:
        blended = rule_probability

    news_boost = min((news_signal.get("severity_score", 0) or 0) / 200.0, 0.15)
    final_probability = float(min(blended + news_boost, 1.0))

    causes = _cause_attribution(feature_row, region, news_signal.get("top_causes", []))

    rationale = [
        f"ML model trained on this river's own history: {'yes' if not fallback_used else 'no (used transparent rule-based fallback)'}",
        f"7-day forecast rainfall total: {feature_row.get('rain_next_7d_mm', 0):.1f} mm",
        f"Worst single forecast day: {feature_row.get('rain_max_day_mm', 0):.1f} mm",
        f"River discharge vs. its own historical high-flow level: {feature_row.get('discharge_ratio_now')}",
        f"Root-zone soil saturation: {feature_row.get('soil_root_wetness')}",
        f"Season: {feature_row.get('seasonal_phase')} (climatological weight {feature_row.get('seasonal_weight')})",
        f"Live verified news/alert corroboration boost applied: +{news_boost:.2f}",
    ]

    return RiskAssessment(
        region=region,
        ml_probability=ml_probability,
        fallback_used=fallback_used,
        risk_tier=_risk_tier(final_probability),
        risk_score_0_100=round(final_probability * 100, 1),
        likely_causes=causes,
        predicted_window_days=(1, 7),
        rationale=rationale,
    )
