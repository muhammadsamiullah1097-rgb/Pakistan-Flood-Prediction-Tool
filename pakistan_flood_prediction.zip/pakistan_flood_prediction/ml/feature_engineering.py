"""
Turns raw API responses (rainfall, river discharge, soil moisture, news
signal) into the numeric feature vectors the risk model consumes, and into
the historical training table.

Every feature here maps to a real physical driver of flooding:
  - rainfall_next_Nd_mm         : how much rain is coming
  - rainfall_intensity_max_mm   : single worst day (drives flash floods more than totals)
  - discharge_ratio_to_p_high   : today's/forecast river discharge as a
                                   fraction of *this river's own* historical
                                   90th-percentile flow (>1.0 = already at
                                   flood stage by its own history)
  - discharge_trend             : is discharge rising or falling day to day
  - soil_root_wetness           : antecedent saturation (0-1)
  - seasonal_weight             : climatological month-of-year risk weight
  - news_severity / news_mentions: live verified-news corroboration signal
  - terrain one-hot flags       : structural exposure type
"""
import numpy as np
import pandas as pd

from config import SEASONAL_CALENDAR, TERRAIN_MECHANISMS


def build_feature_row(region: dict, forecast_json: dict, discharge_forecast_json: dict,
                       discharge_percentiles: dict, soil_json: dict, news_signal: dict,
                       gdacs_active: bool, as_of_month: int) -> dict:
    daily = forecast_json.get("daily", {})
    precip = [v for v in daily.get("precipitation_sum", []) if v is not None]
    rain_next_7d = float(np.sum(precip[:7])) if precip else 0.0
    rain_next_3d = float(np.sum(precip[:3])) if precip else 0.0
    rain_max_day = float(np.max(precip)) if precip else 0.0

    disc_daily = discharge_forecast_json.get("daily", {})
    discharge_series = [v for v in disc_daily.get("river_discharge", []) if v is not None]
    discharge_now = discharge_series[0] if discharge_series else None
    discharge_in_3d = discharge_series[3] if len(discharge_series) > 3 else discharge_now

    p_high = discharge_percentiles.get("p_high")
    p_severe = discharge_percentiles.get("p_severe")
    if discharge_now is not None and p_high:
        discharge_ratio_now = discharge_now / p_high
    else:
        discharge_ratio_now = None
    if discharge_in_3d is not None and p_high:
        discharge_ratio_3d = discharge_in_3d / p_high
    else:
        discharge_ratio_3d = None

    if discharge_now is not None and discharge_in_3d is not None:
        discharge_trend = discharge_in_3d - discharge_now
    else:
        discharge_trend = 0.0

    root_wetness = soil_json.get("root_zone_wetness") if soil_json else None

    seasonal_weight = SEASONAL_CALENDAR.get(as_of_month, {}).get("weight", 0.2)
    seasonal_phase = SEASONAL_CALENDAR.get(as_of_month, {}).get("phase", "unknown")

    terrain = region.get("terrain", "arid_plain")
    terrain_flags = {f"terrain_{t}": int(terrain == t) for t in TERRAIN_MECHANISMS}

    row = {
        "province": region["province"],
        "district": region["district"],
        "city": region["city"],
        "river": region.get("river"),
        "historical_flood_prone": int(region.get("historical_flood_prone", False)),
        "rain_next_3d_mm": rain_next_3d,
        "rain_next_7d_mm": rain_next_7d,
        "rain_max_day_mm": rain_max_day,
        "discharge_now": discharge_now,
        "discharge_p_high": p_high,
        "discharge_p_severe": p_severe,
        "discharge_ratio_now": discharge_ratio_now,
        "discharge_ratio_3d": discharge_ratio_3d,
        "discharge_trend": discharge_trend,
        "soil_root_wetness": root_wetness,
        "seasonal_weight": seasonal_weight,
        "seasonal_phase": seasonal_phase,
        "news_mentions": news_signal.get("mentions", 0),
        "news_severity": news_signal.get("severity_score", 0),
        "gdacs_active_alert": int(gdacs_active),
        **terrain_flags,
    }
    return row


def build_training_table(historical_rain_daily: dict, historical_discharge_daily: dict,
                          high_flow_threshold: float) -> pd.DataFrame:
    """
    Builds a per-day supervised-learning table for ONE location from its own
    historical rainfall + discharge series:
      features: rolling rainfall sums/lags + month (seasonality)
      label:    1 if next day's discharge exceeds this location's own
                historical 90th-percentile discharge (a real, data-derived
                "high-flow event"), else 0.
    """
    dates = historical_rain_daily.get("time", [])
    rain = historical_rain_daily.get("precipitation_sum", [])
    disc = historical_discharge_daily.get("river_discharge", [])

    n = min(len(dates), len(rain), len(disc))
    df = pd.DataFrame({
        "date": pd.to_datetime(dates[:n]),
        "rain_mm": pd.Series(rain[:n], dtype=float),
        "discharge": pd.Series(disc[:n], dtype=float),
    }).dropna()

    df["rain_lag1"] = df["rain_mm"].shift(1).fillna(0)
    df["rain_lag2"] = df["rain_mm"].shift(2).fillna(0)
    df["rain_3d_sum"] = df["rain_mm"].rolling(3, min_periods=1).sum()
    df["rain_7d_sum"] = df["rain_mm"].rolling(7, min_periods=1).sum()
    df["month"] = df["date"].dt.month
    df["discharge_next_day"] = df["discharge"].shift(-1)
    df["label_high_flow_next_day"] = (df["discharge_next_day"] > high_flow_threshold).astype(int)

    df = df.dropna(subset=["discharge_next_day"])
    return df
