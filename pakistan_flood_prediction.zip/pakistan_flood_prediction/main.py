"""
End-to-end orchestration.

    python main.py --scope all
    python main.py --scope province --name Sindh
    python main.py --scope city --name Multan

Requires outbound internet access to:
  api.open-meteo.com, archive-api.open-meteo.com, flood-api.open-meteo.com,
  power.larc.nasa.gov, www.gdacs.org, api.reliefweb.int
"""
import argparse
import os
import sys
import traceback
from datetime import datetime, timedelta

from tqdm import tqdm

from data.pakistan_regions import PAKISTAN_REGIONS, regions_in_province, find_city
from ingestion import weather_client, flood_client, soil_moisture_client, gdacs_client, reliefweb_client
from nlp.news_analyzer import analyze_reports, news_signal_for_place
from ml.feature_engineering import build_feature_row, build_training_table
from ml.risk_model import train_location_model, assess_region
from reports.report_generator import region_report, region_markdown, national_summary_markdown, save_report

OUTPUT_DIR = "output"
REGIONS_OUTPUT_DIR = os.path.join(OUTPUT_DIR, "regions")


def select_regions(scope: str, name: str):
    if scope == "all":
        return PAKISTAN_REGIONS
    if scope == "province":
        regions = regions_in_province(name)
        if not regions:
            sys.exit(f"No regions found for province '{name}'. See data/pakistan_regions.py for valid names.")
        return regions
    if scope == "city":
        region = find_city(name)
        if not region:
            sys.exit(f"City '{name}' not found in gazetteer. See data/pakistan_regions.py for valid names.")
        return [region]
    sys.exit("Unknown --scope, use one of: all | province | city")


def fetch_live_context():
    """One-time, national-level live fetches shared across all regions."""
    print("Fetching live GDACS alerts (Pakistan floods)...")
    try:
        gdacs_alerts = gdacs_client.active_pakistan_flood_alerts()
    except Exception as exc:
        print(f"  ! GDACS fetch failed ({exc}); continuing without live GDACS signal.")
        gdacs_alerts = []
    gdacs_is_active = len(gdacs_alerts) > 0

    print("Fetching verified ReliefWeb (UN OCHA) flood reports for Pakistan...")
    try:
        reports = reliefweb_client.fetch_pakistan_flood_reports(limit=40)
    except Exception as exc:
        print(f"  ! ReliefWeb fetch failed ({exc}); continuing without verified news signal.")
        reports = []

    combined_texts = reports + [
        {"title": a.get("title"), "body": a.get("summary")} for a in gdacs_alerts
    ]
    news_analysis = analyze_reports(combined_texts)
    return gdacs_is_active, news_analysis


def process_region(region: dict, gdacs_is_active: bool, news_analysis: dict, train_ml: bool):
    lat, lon = region["lat"], region["lon"]
    today = datetime.utcnow().date()

    forecast_json = weather_client.fetch_forecast(lat, lon, forecast_days=16)
    discharge_forecast_json = flood_client.fetch_discharge_forecast(lat, lon, forecast_days=30)
    discharge_history_json = flood_client.fetch_discharge_history(lat, lon)
    discharge_percentiles = flood_client.compute_discharge_percentiles(discharge_history_json)

    soil_start = (today - timedelta(days=3)).strftime("%Y%m%d")
    soil_end = today.strftime("%Y%m%d")
    try:
        soil_raw = soil_moisture_client.fetch_soil_moisture(lat, lon, soil_start, soil_end)
        soil_latest = soil_moisture_client.latest_soil_wetness(soil_raw)
    except Exception:
        soil_latest = {"root_zone_wetness": None}

    news_signal = news_signal_for_place(news_analysis, region["city"])

    feature_row = build_feature_row(
        region=region,
        forecast_json=forecast_json,
        discharge_forecast_json=discharge_forecast_json,
        discharge_percentiles=discharge_percentiles,
        soil_json=soil_latest,
        news_signal=news_signal,
        gdacs_active=gdacs_is_active,
        as_of_month=today.month,
    )

    trained_model = None
    if train_ml and discharge_percentiles.get("p_high"):
        rain_hist_json = weather_client.fetch_historical(
            lat, lon,
            start_date="1991-01-01",
            end_date=(today - timedelta(days=1)).strftime("%Y-%m-%d"),
        )
        training_df = build_training_table(
            rain_hist_json.get("daily", {}),
            discharge_history_json.get("daily", {}),
            high_flow_threshold=discharge_percentiles["p_high"],
        )
        trained_model, _metrics = train_location_model(training_df)

    assessment = assess_region(region, feature_row, trained_model, news_signal)
    report = region_report(assessment, feature_row, news_signal)
    markdown = region_markdown(report)
    save_report(report, markdown, REGIONS_OUTPUT_DIR)
    return report


def main():
    parser = argparse.ArgumentParser(description="Pakistan Flood Early-Warning System")
    parser.add_argument("--scope", choices=["all", "province", "city"], default="all")
    parser.add_argument("--name", default=None, help="Province or city name (required unless --scope all)")
    parser.add_argument("--no-ml", action="store_true", help="Skip per-location ML training (rule-based fallback only, much faster)")
    args = parser.parse_args()

    regions = select_regions(args.scope, args.name)
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    gdacs_is_active, news_analysis = fetch_live_context()

    all_reports = []
    for region in tqdm(regions, desc="Assessing regions"):
        try:
            report = process_region(region, gdacs_is_active, news_analysis, train_ml=not args.no_ml)
            all_reports.append(report)
        except Exception as exc:
            print(f"  ! Failed for {region['city']}: {exc}")
            traceback.print_exc()

    summary_md = national_summary_markdown(all_reports)
    with open(os.path.join(OUTPUT_DIR, "national_flood_risk_report.md"), "w", encoding="utf-8") as f:
        f.write(summary_md)

    import json
    with open(os.path.join(OUTPUT_DIR, "national_flood_risk_report.json"), "w", encoding="utf-8") as f:
        json.dump(all_reports, f, indent=2, ensure_ascii=False)

    print(f"\nDone. {len(all_reports)} regions assessed.")
    print(f"National summary: {OUTPUT_DIR}/national_flood_risk_report.md")
    print(f"Per-region reports: {REGIONS_OUTPUT_DIR}/<city>.md")


if __name__ == "__main__":
    main()
