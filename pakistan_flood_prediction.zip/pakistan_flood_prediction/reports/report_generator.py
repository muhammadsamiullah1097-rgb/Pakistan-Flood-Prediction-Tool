"""
Turns each RiskAssessment into the full, human-readable report the project
was asked for: why, where, when, how, how much, disaster type, damage
risk, and people/area/demography context -- per region and rolled up into
one national report.
"""
import json
from datetime import datetime, timezone

DAMAGE_RISK_NOTES = {
    "urban": "Road/street inundation, basement & ground-floor property damage, traffic and power-supply disruption, waterborne-disease risk in stagnant water.",
    "riverine_plain": "Cropland submersion (especially cotton/rice/sugarcane), embankment/bund breaches, village-level displacement, livestock losses, road/bridge damage.",
    "hill_torrent": "Very fast-onset flash flooding with short warning time; highest risk to life for people near dry stream beds (nullahs); road and bridge washouts.",
    "glacial_mountain": "GLOF and snow/glacial-melt surges can destroy roads, bridges, and hydropower/irrigation infrastructure with little warning; tourist/traveller stranding risk.",
    "coastal_delta": "Storm surge + high tide compounding; saline intrusion into farmland; fishing-community livelihood disruption; slower floodwater recession.",
    "arid_plain": "Infrastructure often not designed for heavy rain (poor drainage); comparatively rare but can be severe when it happens because of low preparedness.",
}

DEMOGRAPHY_NOTES = {
    "urban": "Dense low-income settlements near drains/nullahs and katchi abadis (informal settlements) are disproportionately exposed; daily-wage labourers face the largest income shock.",
    "riverine_plain": "Rural farming communities dependent on the current crop cycle are most exposed; tenant farmers/haris often bear losses without owning the land.",
    "hill_torrent": "Mountain/hill communities, often with limited road access and thinner emergency-service coverage, face higher relative risk to life.",
    "glacial_mountain": "Remote valley communities (Chitral, Gilgit-Baltistan, upper Neelum) with seasonal-only road access are hardest to reach for rescue/relief once cut off.",
    "coastal_delta": "Fishing and small-farming coastal communities, some already dealing with sea intrusion/salinity, face compounding livelihood loss.",
    "arid_plain": "Communities with limited historical flood experience may under-prepare, increasing relative vulnerability despite lower average frequency.",
}


def _iso_now():
    return datetime.now(timezone.utc).isoformat()


def region_report(assessment, feature_row: dict, news_signal: dict) -> dict:
    region = assessment.region
    terrain = region.get("terrain", "arid_plain")

    report = {
        "generated_at_utc": _iso_now(),
        "location": {
            "province": region["province"],
            "division": region.get("division"),
            "district": region["district"],
            "city": region["city"],
            "lat": region["lat"],
            "lon": region["lon"],
            "river": region.get("river"),
            "population_est": region.get("population_est"),
        },
        "prediction": {
            "risk_tier": assessment.risk_tier,
            "risk_score_0_100": assessment.risk_score_0_100,
            "predicted_window_days_from_now": assessment.predicted_window_days,
            "ml_model_used": not assessment.fallback_used,
            "ml_probability": assessment.ml_probability,
        },
        "why_likely_causes": assessment.likely_causes,
        "how_reasoning_trace": assessment.rationale,
        "disaster_type": terrain.replace("_", " "),
        "how_much_damage_risk": DAMAGE_RISK_NOTES.get(terrain),
        "people_and_demography": DEMOGRAPHY_NOTES.get(terrain),
        "historical_context": region.get("flood_notes"),
        "live_verified_signal": {
            "news_mentions_recent": news_signal.get("mentions", 0),
            "news_severity_score": news_signal.get("severity_score", 0),
            "latest_verified_headline": news_signal.get("latest_headline"),
        },
        "raw_features": feature_row,
    }
    return report


def region_markdown(report: dict) -> str:
    loc = report["location"]
    pred = report["prediction"]
    lines = [
        f"# {loc['city']}, {loc['district']} District, {loc['province']}",
        "",
        f"**Risk tier: {pred['risk_tier']}**  (score {pred['risk_score_0_100']}/100, "
        f"predicted window: next {pred['predicted_window_days_from_now'][1]} days)",
        "",
        f"- River / drainage: {loc.get('river') or 'no major mapped river (local drainage-driven)'}",
        f"- Approx. population exposed: {loc.get('population_est'):,}" if loc.get("population_est") else "- Population: n/a",
        f"- Disaster type: {report['disaster_type']}",
        "",
        "## Why (likely causes)",
    ]
    for c in report["why_likely_causes"]:
        lines.append(f"- {c}")

    lines += ["", "## How much (expected damage risk)", report["how_much_damage_risk"] or "n/a"]
    lines += ["", "## Who is most exposed (people / demography)", report["people_and_demography"] or "n/a"]

    if report.get("historical_context"):
        lines += ["", "## Historical context", report["historical_context"]]

    lv = report["live_verified_signal"]
    lines += [
        "",
        "## Live verified news/alert cross-check",
        f"- Recent verified reports mentioning this location: {lv['news_mentions_recent']}",
        f"- Severity score from verified reporting: {lv['news_severity_score']}",
        f"- Latest verified headline: {lv['latest_verified_headline'] or 'none found in current window'}",
        "",
        "## Reasoning trace (how the score was built)",
    ]
    for r in report["how_reasoning_trace"]:
        lines.append(f"- {r}")

    lines += ["", f"_Generated {report['generated_at_utc']}_"]
    return "\n".join(lines)


def national_summary_markdown(all_reports: list) -> str:
    tiers_order = {"SEVERE": 0, "HIGH": 1, "MODERATE": 2, "LOW": 3}
    ranked = sorted(all_reports, key=lambda r: (tiers_order.get(r["prediction"]["risk_tier"], 4),
                                                 -r["prediction"]["risk_score_0_100"]))
    lines = [
        "# Pakistan National Flood Risk Summary",
        f"_Generated {_iso_now()}_",
        "",
        f"Regions assessed: {len(all_reports)}",
        "",
        "| Risk Tier | City | District | Province | Score | Top cause |",
        "|---|---|---|---|---|---|",
    ]
    for r in ranked:
        loc = r["location"]
        pred = r["prediction"]
        top_cause = r["why_likely_causes"][0] if r["why_likely_causes"] else ""
        lines.append(
            f"| {pred['risk_tier']} | {loc['city']} | {loc['district']} | {loc['province']} | "
            f"{pred['risk_score_0_100']} | {top_cause} |"
        )
    return "\n".join(lines)


def save_report(report: dict, markdown: str, out_dir: str):
    import os
    os.makedirs(out_dir, exist_ok=True)
    city_slug = report["location"]["city"].lower().replace(" ", "_")
    with open(os.path.join(out_dir, f"{city_slug}.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    with open(os.path.join(out_dir, f"{city_slug}.md"), "w", encoding="utf-8") as f:
        f.write(markdown)
