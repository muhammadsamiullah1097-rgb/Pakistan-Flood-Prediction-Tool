"""
Client for the ReliefWeb API, run by UN OCHA (Office for the Coordination
of Humanitarian Affairs). Free, public, JSON, no API key -- ReliefWeb only
asks that requests include an `appname` query parameter identifying the
calling application (not a secret, just good citizenship / rate-limit
attribution).

This is our source of *verified* flood-related situation reports and news
for the NLP layer, instead of unverified scraped news sites.

Docs: https://apidoc.reliefweb.int/
"""
import time
import requests

from config import RELIEFWEB_API_URL, APP_NAME, REQUEST_TIMEOUT_SECONDS, REQUEST_RETRIES


def _post_with_retries(url, payload):
    last_err = None
    for attempt in range(REQUEST_RETRIES):
        try:
            resp = requests.post(url, params={"appname": APP_NAME}, json=payload, timeout=REQUEST_TIMEOUT_SECONDS)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as exc:
            last_err = exc
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"ReliefWeb request failed after {REQUEST_RETRIES} attempts: {last_err}")


def fetch_pakistan_flood_reports(limit: int = 30, days_back: int = 60) -> list:
    """
    Returns the most recent verified ReliefWeb reports mentioning Pakistan
    and floods, newest first, with title + short body snippet for the NLP
    layer to analyse.
    """
    payload = {
        "limit": limit,
        "sort": ["date:desc"],
        "filter": {
            "operator": "AND",
            "conditions": [
                {"field": "country", "value": "Pakistan"},
                {"field": "disaster_type", "value": "Flood"},
            ],
        },
        "fields": {
            "include": ["title", "body", "date.created", "source", "url"]
        },
    }
    data = _post_with_retries(RELIEFWEB_API_URL, payload)
    items = data.get("data", [])
    reports = []
    for item in items:
        fields = item.get("fields", {})
        reports.append({
            "id": item.get("id"),
            "title": fields.get("title"),
            "body": fields.get("body", ""),
            "date": fields.get("date", {}).get("created"),
            "url": fields.get("url"),
            "source": [s.get("name") for s in fields.get("source", [])] if fields.get("source") else [],
        })
    return reports
