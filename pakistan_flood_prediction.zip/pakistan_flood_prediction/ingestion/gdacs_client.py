"""
Client for GDACS -- the Global Disaster Alert and Coordination System, a
free public cooperation framework between the United Nations and the
European Commission's Joint Research Centre. Used here as a live
verified cross-check: "has an internationally recognised body already
declared an active flood alert here, right now?"

GDACS publishes a continuously updated public GeoRSS feed with no API key
required. Alert levels are Green (no/low impact expected), Orange
(medium), Red (high, likely to require international response).

Feed: https://www.gdacs.org/xml/rss.xml
"""
import time
import requests
import feedparser

from config import GDACS_RSS_URL, REQUEST_TIMEOUT_SECONDS, REQUEST_RETRIES

PAKISTAN_NAME_VARIANTS = ["pakistan"]


def fetch_active_alerts() -> list:
    """
    Returns a list of dicts for every currently active GDACS alert
    worldwide. Filtering to Pakistan/floods happens in
    `active_pakistan_flood_alerts` below so the raw feed can also be reused
    for other hazard types if useful.
    """
    last_err = None
    raw_text = None
    for attempt in range(REQUEST_RETRIES):
        try:
            resp = requests.get(GDACS_RSS_URL, timeout=REQUEST_TIMEOUT_SECONDS)
            resp.raise_for_status()
            raw_text = resp.text
            break
        except requests.RequestException as exc:
            last_err = exc
            time.sleep(1.5 * (attempt + 1))
    if raw_text is None:
        raise RuntimeError(f"GDACS feed request failed after {REQUEST_RETRIES} attempts: {last_err}")

    feed = feedparser.parse(raw_text)
    alerts = []
    for entry in feed.entries:
        alerts.append({
            "title": entry.get("title"),
            "summary": entry.get("summary", ""),
            "link": entry.get("link"),
            "published": entry.get("published", None),
            "gdacs_alertlevel": entry.get("gdacs_alertlevel", entry.get("alertlevel", None)),
            "gdacs_eventtype": entry.get("gdacs_eventtype", entry.get("eventtype", None)),
            "gdacs_country": entry.get("gdacs_country", entry.get("country", "")),
            "gdacs_eventid": entry.get("gdacs_eventid", None),
        })
    return alerts


def active_pakistan_flood_alerts() -> list:
    all_alerts = fetch_active_alerts()
    result = []
    for a in all_alerts:
        country = (a.get("gdacs_country") or "").lower()
        event_type = (a.get("gdacs_eventtype") or "").upper()
        title = (a.get("title") or "").lower()
        is_pakistan = any(v in country for v in PAKISTAN_NAME_VARIANTS) or "pakistan" in title
        is_flood = event_type == "FL" or "flood" in title
        if is_pakistan and is_flood:
            result.append(a)
    return result
