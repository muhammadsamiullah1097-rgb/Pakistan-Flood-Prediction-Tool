"""
Client for the Open-Meteo Weather Forecast API and Historical Weather
(Archive/ERA5) API. Free, no API key, global coverage, updated multiple
times per day.

Docs:
  https://open-meteo.com/en/docs           (forecast)
  https://open-meteo.com/en/docs/historical-weather-api  (archive/ERA5)
"""
import time
import requests

from config import (
    OPEN_METEO_FORECAST_URL,
    OPEN_METEO_ARCHIVE_URL,
    REQUEST_TIMEOUT_SECONDS,
    REQUEST_RETRIES,
)

DAILY_VARS = [
    "precipitation_sum",
    "precipitation_probability_max",
    "rain_sum",
    "temperature_2m_max",
    "temperature_2m_min",
    "windspeed_10m_max",
]

HOURLY_SOIL_VARS = [
    "soil_moisture_0_to_7cm",
    "soil_moisture_7_to_28cm",
]


def _get_with_retries(url, params):
    last_err = None
    for attempt in range(REQUEST_RETRIES):
        try:
            resp = requests.get(url, params=params, timeout=REQUEST_TIMEOUT_SECONDS)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as exc:
            last_err = exc
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Open-Meteo request failed after {REQUEST_RETRIES} attempts: {last_err}")


def fetch_forecast(lat: float, lon: float, forecast_days: int = 16) -> dict:
    """
    Daily rainfall/temperature/wind forecast for the next `forecast_days`
    (Open-Meteo supports up to 16 days for standard weather variables).
    """
    params = {
        "latitude": lat,
        "longitude": lon,
        "daily": ",".join(DAILY_VARS),
        "hourly": ",".join(HOURLY_SOIL_VARS),
        "timezone": "auto",
        "forecast_days": min(forecast_days, 16),
    }
    return _get_with_retries(OPEN_METEO_FORECAST_URL, params)


def fetch_historical(lat: float, lon: float, start_date: str, end_date: str) -> dict:
    """
    Historical daily rainfall (ERA5 reanalysis) for an arbitrary date range,
    used both to build the ML training set and to compute each location's
    own seasonal-normal rainfall baseline.
    """
    params = {
        "latitude": lat,
        "longitude": lon,
        "start_date": start_date,
        "end_date": end_date,
        "daily": "precipitation_sum,rain_sum,temperature_2m_max",
        "timezone": "auto",
    }
    return _get_with_retries(OPEN_METEO_ARCHIVE_URL, params)
