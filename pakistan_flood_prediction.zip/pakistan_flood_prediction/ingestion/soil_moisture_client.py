"""
Client for NASA POWER (Prediction Of Worldwide Energy Resources) API.
Free, no API key, maintained by NASA Langley Research Center.

Used here specifically for root-zone and surface soil-moisture wetness
fraction, which is the key "antecedent condition" that determines whether
a given amount of rainfall soaks in harmlessly or runs off and floods --
the same rainfall total can produce very different outcomes depending on
how saturated the ground already is.

Docs: https://power.larc.nasa.gov/docs/services/api/
"""
import time
import requests

from config import NASA_POWER_URL, REQUEST_TIMEOUT_SECONDS, REQUEST_RETRIES

PARAMETERS = "PRECTOTCORR,GWETROOT,GWETTOP,T2M"


def _get_with_retries(params):
    last_err = None
    for attempt in range(REQUEST_RETRIES):
        try:
            resp = requests.get(NASA_POWER_URL, params=params, timeout=REQUEST_TIMEOUT_SECONDS)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as exc:
            last_err = exc
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"NASA POWER request failed after {REQUEST_RETRIES} attempts: {last_err}")


def fetch_soil_moisture(lat: float, lon: float, start: str, end: str) -> dict:
    """
    start/end format: YYYYMMDD (NASA POWER's date format, different from
    Open-Meteo's YYYY-MM-DD -- handled by the caller).
    GWETROOT / GWETTOP are wetness fractions from 0 (bone dry) to 1 (saturated).
    """
    params = {
        "parameters": PARAMETERS,
        "community": "AG",
        "longitude": lon,
        "latitude": lat,
        "start": start,
        "end": end,
        "format": "JSON",
    }
    return _get_with_retries(params)


def latest_soil_wetness(power_json: dict) -> dict:
    """Extract the most recent day's root-zone/surface wetness fraction."""
    try:
        series = power_json["properties"]["parameter"]["GWETROOT"]
        latest_date = sorted(series.keys())[-1]
        return {
            "date": latest_date,
            "root_zone_wetness": series[latest_date],
            "surface_wetness": power_json["properties"]["parameter"]["GWETTOP"].get(latest_date),
        }
    except (KeyError, IndexError, TypeError):
        return {"date": None, "root_zone_wetness": None, "surface_wetness": None}
