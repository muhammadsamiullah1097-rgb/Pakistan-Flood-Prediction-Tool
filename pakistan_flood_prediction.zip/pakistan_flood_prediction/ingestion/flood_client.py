"""
Client for the Open-Meteo Flood API, which serves the Global Flood
Awareness System (GloFAS) hydrological model -- the same model family used
by the Copernicus Emergency Management Service for real flood early
warning in Europe and globally.

Free, no API key. Resolution ~5 km grid cells snapped to the nearest
modelled river channel. Historical data from 1984; forecast up to ~210
days (with widening ensemble uncertainty beyond ~30 days, which we surface
rather than hide).

Docs: https://open-meteo.com/en/docs/flood-api
"""
import time
import requests
import numpy as np

from config import (
    OPEN_METEO_FLOOD_URL,
    REQUEST_TIMEOUT_SECONDS,
    REQUEST_RETRIES,
    HISTORICAL_BASELINE_START,
    HISTORICAL_BASELINE_END,
    HIGH_FLOW_PERCENTILE,
    SEVERE_FLOW_PERCENTILE,
)


def _get_with_retries(params):
    last_err = None
    for attempt in range(REQUEST_RETRIES):
        try:
            resp = requests.get(OPEN_METEO_FLOOD_URL, params=params, timeout=REQUEST_TIMEOUT_SECONDS)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as exc:
            last_err = exc
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Open-Meteo Flood API request failed after {REQUEST_RETRIES} attempts: {last_err}")


def fetch_discharge_forecast(lat: float, lon: float, forecast_days: int = 30) -> dict:
    """
    Daily river discharge (m^3/s) forecast, ensemble mean + spread, for the
    largest modelled river within ~5 km of the given coordinate.
    """
    params = {
        "latitude": lat,
        "longitude": lon,
        "daily": "river_discharge,river_discharge_mean,river_discharge_max,river_discharge_min,river_discharge_p25,river_discharge_p75",
        "forecast_days": forecast_days,
    }
    return _get_with_retries(params)


def fetch_discharge_history(lat: float, lon: float,
                             start_date: str = HISTORICAL_BASELINE_START,
                             end_date: str = HISTORICAL_BASELINE_END) -> dict:
    """
    Historical daily discharge, used to compute this location's own
    percentile thresholds (its personal "flood stage") instead of applying
    one generic number to every river in the country.
    """
    params = {
        "latitude": lat,
        "longitude": lon,
        "daily": "river_discharge",
        "start_date": start_date,
        "end_date": end_date,
    }
    return _get_with_retries(params)


def compute_discharge_percentiles(history_json: dict) -> dict:
    """
    Returns this location's own high-flow / severe-flow discharge
    thresholds (m^3/s), derived purely from its own multi-decade record --
    no invented numbers.
    """
    try:
        values = history_json["daily"]["river_discharge"]
    except (KeyError, TypeError):
        return {"p_high": None, "p_severe": None, "median": None, "n_days": 0}

    values = np.array([v for v in values if v is not None], dtype=float)
    if values.size == 0:
        return {"p_high": None, "p_severe": None, "median": None, "n_days": 0}

    return {
        "p_high": float(np.percentile(values, HIGH_FLOW_PERCENTILE)),
        "p_severe": float(np.percentile(values, SEVERE_FLOW_PERCENTILE)),
        "median": float(np.median(values)),
        "n_days": int(values.size),
    }
