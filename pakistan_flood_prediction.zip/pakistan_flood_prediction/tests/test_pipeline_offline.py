"""
Offline smoke test: exercises the FULL pipeline (feature engineering ->
per-location ML training -> risk assessment -> report generation) using
mocked payloads shaped exactly like the real Open-Meteo / NASA POWER
responses, so you can confirm everything works *before* you even need
live internet access to the real APIs.

Run:  python -m tests.test_pipeline_offline   (from the project root)
"""
import random
from datetime import datetime, timedelta

from data.pakistan_regions import find_city
from ingestion.flood_client import compute_discharge_percentiles
from ml.feature_engineering import build_feature_row, build_training_table
from ml.risk_model import train_location_model, assess_region
from nlp.news_analyzer import analyze_reports, news_signal_for_place
from reports.report_generator import region_report, region_markdown, national_summary_markdown

random.seed(42)


def _mock_forecast_json(days=16):
    dates = [(datetime(2026, 7, 20) + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days)]
    precip = [round(random.choice([0, 0, 2, 5, 15, 40, 90, 150]) * random.random() + random.random() * 5, 1)
              for _ in range(days)]
    return {"daily": {"time": dates, "precipitation_sum": precip}}


def _mock_discharge_forecast_json(days=30):
    base = 800
    series = [base + random.uniform(-100, 400) for _ in range(days)]
    return {"daily": {"time": [None] * days, "river_discharge": series}}


def _mock_discharge_history_json(n_years=30):
    n_days = n_years * 365
    dates = [(datetime(1991, 1, 1) + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(n_days)]
    series = []
    for d in dates:
        month = int(d.split("-")[1])
        seasonal = 1800 if month in (7, 8) else (900 if month in (6, 9) else 400)
        series.append(max(50, random.gauss(seasonal, seasonal * 0.4)))
    return {"daily": {"time": dates, "river_discharge": series}}


def _mock_rain_history_json(n_years=30):
    n_days = n_years * 365
    dates = [(datetime(1991, 1, 1) + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(n_days)]
    series = []
    for d in dates:
        month = int(d.split("-")[1])
        seasonal = 12 if month in (7, 8) else (5 if month in (6, 9) else 1)
        series.append(max(0, random.gauss(seasonal, seasonal * 1.5)))
    return {"daily": {"time": dates, "precipitation_sum": series}}


def run():
    region = find_city("Multan")
    assert region is not None, "Gazetteer lookup failed"

    discharge_history_json = _mock_discharge_history_json()
    discharge_percentiles = compute_discharge_percentiles(discharge_history_json)
    assert discharge_percentiles["p_high"] is not None

    fake_reports = [
        {"title": "Multan flood alert: Chenab river rising, evacuations underway",
         "body": "Heavy monsoon rainfall has caused the Chenab to swell near Multan, prompting evacuations."},
    ]
    news_analysis = analyze_reports(fake_reports)
    news_signal = news_signal_for_place(news_analysis, "Multan")

    feature_row = build_feature_row(
        region=region,
        forecast_json=_mock_forecast_json(),
        discharge_forecast_json=_mock_discharge_forecast_json(),
        discharge_percentiles=discharge_percentiles,
        soil_json={"root_zone_wetness": 0.81},
        news_signal=news_signal,
        gdacs_active=True,
        as_of_month=7,
    )

    training_df = build_training_table(
        _mock_rain_history_json()["daily"], discharge_history_json["daily"], discharge_percentiles["p_high"]
    )
    model, metrics = train_location_model(training_df)
    assert model is not None, f"Model training failed: {metrics}"

    assessment = assess_region(region, feature_row, model, news_signal)
    assert assessment.risk_tier in ("LOW", "MODERATE", "HIGH", "SEVERE")

    report = region_report(assessment, feature_row, news_signal)
    md = region_markdown(report)
    assert "Risk tier" in md

    national_md = national_summary_markdown([report])
    assert "National Flood Risk Summary" in national_md

    print("OK -- full pipeline (feature engineering -> ML -> risk assessment -> reporting) runs cleanly.")
    print(f"Sample result: {region['city']} -> {assessment.risk_tier} ({assessment.risk_score_0_100}/100)")


if __name__ == "__main__":
    run()
