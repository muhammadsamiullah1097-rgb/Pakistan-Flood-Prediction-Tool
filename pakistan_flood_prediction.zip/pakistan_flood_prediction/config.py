"""
Global configuration: API endpoints, physical thresholds, and the Pakistan
monsoon/seasonal calendar used to weight risk by time of year.

Nothing here needs an API key. Every base URL below is a free, public,
actively maintained endpoint as of 2026.
"""

# ---------------------------------------------------------------------------
# API base URLs
# ---------------------------------------------------------------------------
OPEN_METEO_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
OPEN_METEO_ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
OPEN_METEO_FLOOD_URL = "https://flood-api.open-meteo.com/v1/flood"
NASA_POWER_URL = "https://power.larc.nasa.gov/api/temporal/daily/point"
GDACS_RSS_URL = "https://www.gdacs.org/xml/rss.xml"
GDACS_EVENTLIST_URL = "https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH"
RELIEFWEB_API_URL = "https://api.reliefweb.int/v2/reports"
RELIEFWEB_DISASTERS_URL = "https://api.reliefweb.int/v2/disasters"
APP_NAME = "pk-flood-early-warning-noncommercial"  # ReliefWeb asks for an identifying appname, not a secret key

REQUEST_TIMEOUT_SECONDS = 25
REQUEST_RETRIES = 3

# ---------------------------------------------------------------------------
# Historical baseline window used to compute each river point's own
# "normal" discharge distribution (percentiles), per Open-Meteo Flood API's
# GloFAS reanalysis, which is available from 1984 onward.
# ---------------------------------------------------------------------------
HISTORICAL_BASELINE_START = "1991-01-01"
HISTORICAL_BASELINE_END = "2020-12-31"

# Discharge percentile above which a day is treated as a "high-flow / flood
# stage" ground-truth label when training the classifier.
HIGH_FLOW_PERCENTILE = 90
SEVERE_FLOW_PERCENTILE = 97

# ---------------------------------------------------------------------------
# Rainfall thresholds (mm / 24h) used by the rule-based cause-attribution
# layer. These are broadly consistent with PMD's own "heavy/very heavy/
# extremely heavy" rainfall categories used in public bulletins.
# ---------------------------------------------------------------------------
RAINFALL_MODERATE_MM = 25
RAINFALL_HEAVY_MM = 65
RAINFALL_VERY_HEAVY_MM = 130
RAINFALL_EXTREME_MM = 200

# Soil moisture (root-zone wetness fraction 0-1) above which ground is
# considered "saturated" -> same rainfall causes disproportionate runoff.
SOIL_SATURATION_THRESHOLD = 0.75

# ---------------------------------------------------------------------------
# Pakistan's monsoon / seasonal calendar (month -> phase, weight)
# Weight is a 0-1 multiplier reflecting typical climatological flood
# likelihood in that month, independent of any single year's forecast.
# Derived from PMD's published seasonal outlooks and long-run monsoon
# onset/withdrawal norms (approx. 26 June onset, late Sept withdrawal).
# ---------------------------------------------------------------------------
SEASONAL_CALENDAR = {
    1: {"phase": "winter / western disturbance", "weight": 0.10},
    2: {"phase": "late winter rains (hills/GB snowmelt prep)", "weight": 0.12},
    3: {"phase": "pre-monsoon, spring snowmelt begins (north)", "weight": 0.20},
    4: {"phase": "spring snowmelt, hailstorms", "weight": 0.25},
    5: {"phase": "pre-monsoon heat, glacier melt acceleration (GB/Chitral)", "weight": 0.35},
    6: {"phase": "monsoon onset (~26 June, southeast first)", "weight": 0.55},
    7: {"phase": "monsoon peak (highest national risk)", "weight": 1.00},
    8: {"phase": "monsoon peak / riverine flood crest month", "weight": 0.95},
    9: {"phase": "monsoon withdrawal, cyclone/low-pressure risk (Arabian Sea)", "weight": 0.55},
    10: {"phase": "post-monsoon, residual riverine recession", "weight": 0.25},
    11: {"phase": "dry season", "weight": 0.08},
    12: {"phase": "winter, minimal flood risk", "weight": 0.07},
}

# ---------------------------------------------------------------------------
# Terrain-type -> dominant flood mechanism, used by the cause-attribution
# reasoning layer in reports/report_generator.py
# ---------------------------------------------------------------------------
TERRAIN_MECHANISMS = {
    "riverine_plain": "riverine/fluvial flooding from main-stem river spill (Indus/Chenab/Jhelum/Ravi/Sutlej system)",
    "hill_torrent": "flash flooding from hill torrents (nullahs) after intense short-duration rainfall",
    "glacial_mountain": "snow/glacial melt surge and Glacial Lake Outburst Flood (GLOF) risk",
    "coastal_delta": "coastal storm surge, cyclone landfall, and tidal backwater flooding",
    "urban": "urban pluvial flooding from drainage-system overload during intense rainfall",
    "arid_plain": "flash flooding in normally dry channels during unusually heavy rain events",
}
