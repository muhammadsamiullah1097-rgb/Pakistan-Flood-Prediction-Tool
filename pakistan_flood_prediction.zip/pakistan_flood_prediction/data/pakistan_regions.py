"""
Pakistan gazetteer for flood risk monitoring.

Coverage: all 4 provinces + Gilgit-Baltistan + Azad Jammu & Kashmir +
Islamabad Capital Territory, with major cities/districts tagged by:
  - lat/lon           : representative point (good enough for weather/river
                        queries; NOT an official boundary file)
  - river             : nearest major river system feeding local flood risk
                        (None if not primarily riverine)
  - terrain           : dominant flood mechanism key (see config.TERRAIN_MECHANISMS)
  - historical_flood_prone : True if the district has recorded major flood
                        damage in 2010, 2022, 2025 and/or 2026 monsoon seasons
  - population_est    : approximate city/district population (rounded,
                        indicative only -- cross-check PBS census for
                        official figures)

This list is intentionally broad rather than exhaustive down to every one
of Pakistan's ~160 districts/tehsils; it is designed to be easy to extend --
just append another dict with the same keys.
"""

PAKISTAN_REGIONS = [
    # ---------------------------------------------------------------- PUNJAB
    {"province": "Punjab", "division": "Lahore", "district": "Lahore", "city": "Lahore",
     "lat": 31.5497, "lon": 74.3436, "river": "Ravi", "terrain": "urban",
     "historical_flood_prone": True, "population_est": 13000000,
     "flood_notes": "Ravi river spill + urban drainage overload (2025/2026 Ferozewala-Muridke corridor flooding)."},

    {"province": "Punjab", "division": "Gujranwala", "district": "Gujranwala", "city": "Gujranwala",
     "lat": 32.1877, "lon": 74.1945, "river": "Chenab/Degh Nullah", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 2500000,
     "flood_notes": "Repeated 2025-26 flooding from Chenab spill and Degh Nullah overflow."},

    {"province": "Punjab", "division": "Gujranwala", "district": "Sialkot", "city": "Sialkot",
     "lat": 32.4945, "lon": 74.5229, "river": "Chenab/Aik Nullah", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 950000, "flood_notes": "Upstream Chenab + hill torrents from Jammu foothills."},

    {"province": "Punjab", "division": "Gujranwala", "district": "Narowal", "city": "Narowal",
     "lat": 32.1014, "lon": 74.8783, "river": "Ravi/Bein", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 190000, "flood_notes": "First to flood when Ravi/Bein rise from India-side catchment rain."},

    {"province": "Punjab", "division": "Gujranwala", "district": "Gujrat", "city": "Gujrat",
     "lat": 32.5740, "lon": 74.0789, "river": "Chenab", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 460000, "flood_notes": None},

    {"province": "Punjab", "division": "Faisalabad", "district": "Faisalabad", "city": "Faisalabad",
     "lat": 31.4187, "lon": 73.0791, "river": "Chenab (canal-fed)", "terrain": "urban",
     "historical_flood_prone": False, "population_est": 3800000, "flood_notes": "Mostly urban drainage risk, less riverine exposure."},

    {"province": "Punjab", "division": "Faisalabad", "district": "Jhang", "city": "Jhang",
     "lat": 31.2681, "lon": 72.3181, "river": "Chenab/Jhelum confluence (Trimmu)", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 400000, "flood_notes": "Sits near Trimmu Barrage, the Chenab+Jhelum confluence -- historically one of the highest-discharge points in Punjab."},

    {"province": "Punjab", "division": "Faisalabad", "district": "Toba Tek Singh", "city": "Toba Tek Singh",
     "lat": 30.9709, "lon": 72.4839, "river": "Ravi (canal command)", "terrain": "arid_plain",
     "historical_flood_prone": False, "population_est": 150000, "flood_notes": None},

    {"province": "Punjab", "division": "Sargodha", "district": "Sargodha", "city": "Sargodha",
     "lat": 32.0836, "lon": 72.6711, "river": "Jhelum", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 700000, "flood_notes": None},

    {"province": "Punjab", "division": "Sargodha", "district": "Mianwali", "city": "Mianwali",
     "lat": 32.5850, "lon": 71.5480, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 95000, "flood_notes": None},

    {"province": "Punjab", "division": "Sargodha", "district": "Bhakkar", "city": "Bhakkar",
     "lat": 31.6250, "lon": 71.0645, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 100000, "flood_notes": None},

    {"province": "Punjab", "division": "Sargodha", "district": "Chiniot", "city": "Chiniot",
     "lat": 31.7200, "lon": 72.9784, "river": "Chenab", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 320000, "flood_notes": None},

    {"province": "Punjab", "division": "Rawalpindi", "district": "Rawalpindi", "city": "Rawalpindi",
     "lat": 33.6007, "lon": 73.0679, "river": "Nullah Lai", "terrain": "urban",
     "historical_flood_prone": True, "population_est": 2200000,
     "flood_notes": "Nullah Lai flash-flooding is the classic Rawalpindi urban flood risk (repeated in 2025/2026 spells)."},

    {"province": "Punjab", "division": "Rawalpindi", "district": "Attock", "city": "Attock",
     "lat": 33.7666, "lon": 72.3609, "river": "Indus/Kabul confluence", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 210000, "flood_notes": "Sits right at the Indus-Kabul river confluence."},

    {"province": "Punjab", "division": "Rawalpindi", "district": "Jhelum", "city": "Jhelum",
     "lat": 32.9425, "lon": 73.7257, "river": "Jhelum", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 250000, "flood_notes": None},

    {"province": "Punjab", "division": "Multan", "district": "Multan", "city": "Multan",
     "lat": 30.1575, "lon": 71.5249, "river": "Chenab", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 2000000, "flood_notes": None},

    {"province": "Punjab", "division": "Multan", "district": "Khanewal", "city": "Khanewal",
     "lat": 30.3015, "lon": 71.9325, "river": "Ravi", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 190000, "flood_notes": None},

    {"province": "Punjab", "division": "Multan", "district": "Vehari", "city": "Vehari",
     "lat": 30.0453, "lon": 72.3489, "river": "Sutlej", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 175000, "flood_notes": None},

    {"province": "Punjab", "division": "Dera Ghazi Khan", "district": "Dera Ghazi Khan", "city": "Dera Ghazi Khan",
     "lat": 30.0561, "lon": 70.6346, "river": "Indus / hill torrents (Suleiman Range)", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 500000,
     "flood_notes": "Classic hill-torrent (nullah) flash-flood risk from Suleiman Range, plus Indus spill."},

    {"province": "Punjab", "division": "Dera Ghazi Khan", "district": "Muzaffargarh", "city": "Muzaffargarh",
     "lat": 30.0725, "lon": 71.1928, "river": "Chenab/Indus (between rivers)", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 260000,
     "flood_notes": "Sits in the Chenab-Indus doab -- among the worst-hit districts in 2010 and 2022."},

    {"province": "Punjab", "division": "Dera Ghazi Khan", "district": "Layyah", "city": "Layyah",
     "lat": 30.9693, "lon": 70.9428, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 120000, "flood_notes": None},

    {"province": "Punjab", "division": "Bahawalpur", "district": "Bahawalpur", "city": "Bahawalpur",
     "lat": 29.3956, "lon": 71.6836, "river": "Sutlej", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 900000, "flood_notes": None},

    {"province": "Punjab", "division": "Bahawalpur", "district": "Rahim Yar Khan", "city": "Rahim Yar Khan",
     "lat": 28.4212, "lon": 70.2989, "river": "Indus/Panjnad", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 450000,
     "flood_notes": "Downstream of the Panjnad confluence -- receives cumulative flow from all five Punjab rivers."},

    {"province": "Punjab", "division": "Sahiwal", "district": "Sahiwal", "city": "Sahiwal",
     "lat": 30.6650, "lon": 73.1114, "river": "Ravi", "terrain": "riverine_plain",
     "historical_flood_prone": False, "population_est": 390000, "flood_notes": None},

    {"province": "Punjab", "division": "Sahiwal", "district": "Okara", "city": "Okara",
     "lat": 30.8100, "lon": 73.4467, "river": "Ravi", "terrain": "riverine_plain",
     "historical_flood_prone": False, "population_est": 300000, "flood_notes": None},

    {"province": "Punjab", "division": "Lahore", "district": "Sheikhupura", "city": "Sheikhupura",
     "lat": 31.7167, "lon": 73.9850, "river": "Ravi/Deg Nullah", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 470000,
     "flood_notes": "Among the worst-hit districts in the 2025/2026 Punjab monsoon floods (Sheikhupura-Muridke belt)."},

    {"province": "Punjab", "division": "Lahore", "district": "Kasur", "city": "Kasur",
     "lat": 31.1179, "lon": 74.4467, "river": "Sutlej", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 400000, "flood_notes": None},

    # ----------------------------------------------------------------- SINDH
    {"province": "Sindh", "division": "Karachi", "district": "Karachi", "city": "Karachi",
     "lat": 24.8607, "lon": 67.0011, "river": "Malir/Lyari (urban streams)", "terrain": "urban",
     "historical_flood_prone": True, "population_est": 16000000,
     "flood_notes": "Extreme urban pluvial flooding risk (2020-style) from drainage/encroachment on the Malir & Lyari river beds; also cyclone/storm-surge exposure from the Arabian Sea."},

    {"province": "Sindh", "division": "Hyderabad", "district": "Hyderabad", "city": "Hyderabad",
     "lat": 25.3960, "lon": 68.3578, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 1900000, "flood_notes": None},

    {"province": "Sindh", "division": "Hyderabad", "district": "Badin", "city": "Badin",
     "lat": 24.6560, "lon": 68.8390, "river": "Indus delta / tail-end drainage", "terrain": "coastal_delta",
     "historical_flood_prone": True, "population_est": 210000,
     "flood_notes": "Tail-end of the Indus delta; embankment-breach risk highlighted again ahead of the 2026 monsoon."},

    {"province": "Sindh", "division": "Hyderabad", "district": "Thatta", "city": "Thatta",
     "lat": 24.7460, "lon": 67.9250, "river": "Indus delta", "terrain": "coastal_delta",
     "historical_flood_prone": True, "population_est": 300000, "flood_notes": "Sea intrusion + delta flooding + cyclone exposure."},

    {"province": "Sindh", "division": "Mirpurkhas", "district": "Mirpurkhas", "city": "Mirpurkhas",
     "lat": 25.5268, "lon": 69.0113, "river": None, "terrain": "arid_plain",
     "historical_flood_prone": True, "population_est": 240000, "flood_notes": "2022-style rainfall-driven flooding despite being off the main river course."},

    {"province": "Sindh", "division": "Shaheed Benazirabad", "district": "Shaheed Benazirabad", "city": "Nawabshah",
     "lat": 26.2442, "lon": 68.4100, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 300000, "flood_notes": None},

    {"province": "Sindh", "division": "Larkana", "district": "Larkana", "city": "Larkana",
     "lat": 27.5590, "lon": 68.2120, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 500000,
     "flood_notes": "Near Manchar Lake system -- spillover from Manchar is a recurring extra flood pathway."},

    {"province": "Sindh", "division": "Larkana", "district": "Dadu", "city": "Dadu",
     "lat": 26.7310, "lon": 67.7750, "river": "Indus / Manchar Lake", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 180000,
     "flood_notes": "2022's most severe Manchar Lake spillway-breach flooding hit this district hardest."},

    {"province": "Sindh", "division": "Larkana", "district": "Jacobabad", "city": "Jacobabad",
     "lat": 28.2820, "lon": 68.4382, "river": "Indus (canal-fed) / hill torrents", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 210000, "flood_notes": None},

    {"province": "Sindh", "division": "Larkana", "district": "Shikarpur", "city": "Shikarpur",
     "lat": 27.9550, "lon": 68.6382, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 220000, "flood_notes": None},

    {"province": "Sindh", "division": "Sukkur", "district": "Sukkur", "city": "Sukkur",
     "lat": 27.7052, "lon": 68.8574, "river": "Indus (Sukkur Barrage)", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 500000,
     "flood_notes": "Sukkur Barrage is the key downstream Indus gauge/control point for Sindh flood staging."},

    {"province": "Sindh", "division": "Sukkur", "district": "Khairpur", "city": "Khairpur",
     "lat": 27.5300, "lon": 68.7590, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 190000, "flood_notes": None},

    {"province": "Sindh", "division": "Sukkur", "district": "Ghotki", "city": "Ghotki",
     "lat": 28.0080, "lon": 69.3160, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 150000, "flood_notes": None},

    {"province": "Sindh", "division": "Sukkur", "district": "Kashmore", "city": "Kashmore",
     "lat": 28.4370, "lon": 69.5870, "river": "Indus (Guddu Barrage)", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 130000,
     "flood_notes": "Guddu Barrage is the first major Sindh gauge point for Indus floodwaters arriving from Punjab."},

    # ---------------------------------------------------------- KHYBER PAKHTUNKHWA
    {"province": "Khyber Pakhtunkhwa", "division": "Peshawar", "district": "Peshawar", "city": "Peshawar",
     "lat": 34.0151, "lon": 71.5249, "river": "Kabul", "terrain": "urban",
     "historical_flood_prone": True, "population_est": 2100000,
     "flood_notes": "2026 monsoon saw significant urban flash flooding (waist-deep water reported July 31, 2026)."},

    {"province": "Khyber Pakhtunkhwa", "division": "Peshawar", "district": "Nowshera", "city": "Nowshera",
     "lat": 33.9410, "lon": 71.9750, "river": "Kabul", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 250000,
     "flood_notes": "Historically the single worst-hit KP town for Kabul river flooding (2010 benchmark disaster)."},

    {"province": "Khyber Pakhtunkhwa", "division": "Peshawar", "district": "Charsadda", "city": "Charsadda",
     "lat": 34.1440, "lon": 71.7400, "river": "Swat/Kabul confluence", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 220000, "flood_notes": None},

    {"province": "Khyber Pakhtunkhwa", "division": "Malakand", "district": "Swat", "city": "Mingora",
     "lat": 34.7717, "lon": 72.3604, "river": "Swat", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 375000,
     "flood_notes": "Swat river flash floods are among the fastest-onset and deadliest in Pakistan (repeated 2022/2025/2026 tourist-stranding events)."},

    {"province": "Khyber Pakhtunkhwa", "division": "Malakand", "district": "Buner", "city": "Daggar",
     "lat": 34.5100, "lon": 72.4500, "river": "Barandu", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 90000, "flood_notes": "2026 monsoon: severe flash flooding and landslide damage."},

    {"province": "Khyber Pakhtunkhwa", "division": "Malakand", "district": "Shangla", "city": "Alpurai",
     "lat": 34.8800, "lon": 72.6600, "river": "Swat tributaries", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 60000, "flood_notes": None},

    {"province": "Khyber Pakhtunkhwa", "division": "Malakand", "district": "Chitral", "city": "Chitral",
     "lat": 35.8500, "lon": 71.7860, "river": "Chitral/Kunar", "terrain": "glacial_mountain",
     "historical_flood_prone": True, "population_est": 55000,
     "flood_notes": "High GLOF (Glacial Lake Outburst Flood) exposure; 2026 flash floods damaged connectivity routes and isolated communities."},

    {"province": "Khyber Pakhtunkhwa", "division": "Hazara", "district": "Abbottabad", "city": "Abbottabad",
     "lat": 34.1463, "lon": 73.2117, "river": None, "terrain": "hill_torrent",
     "historical_flood_prone": False, "population_est": 210000, "flood_notes": None},

    {"province": "Khyber Pakhtunkhwa", "division": "Hazara", "district": "Mansehra", "city": "Mansehra",
     "lat": 34.3300, "lon": 73.2000, "river": "Siran/Kunhar", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 160000, "flood_notes": None},

    {"province": "Khyber Pakhtunkhwa", "division": "Mardan", "district": "Mardan", "city": "Mardan",
     "lat": 34.1989, "lon": 72.0404, "river": "Kalpani/Jindi", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 400000, "flood_notes": None},

    {"province": "Khyber Pakhtunkhwa", "division": "Mardan", "district": "Swabi", "city": "Swabi",
     "lat": 34.1200, "lon": 72.4700, "river": "Indus/Kabul", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 130000, "flood_notes": None},

    {"province": "Khyber Pakhtunkhwa", "division": "Kohat", "district": "Kohat", "city": "Kohat",
     "lat": 33.5900, "lon": 71.4400, "river": None, "terrain": "hill_torrent",
     "historical_flood_prone": False, "population_est": 250000, "flood_notes": None},

    {"province": "Khyber Pakhtunkhwa", "division": "Bannu", "district": "Bannu", "city": "Bannu",
     "lat": 32.9880, "lon": 70.6030, "river": "Kurram/Tochi", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 210000, "flood_notes": None},

    {"province": "Khyber Pakhtunkhwa", "division": "Dera Ismail Khan", "district": "Dera Ismail Khan", "city": "Dera Ismail Khan",
     "lat": 31.8310, "lon": 70.9020, "river": "Indus", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 280000, "flood_notes": None},

    {"province": "Khyber Pakhtunkhwa", "division": "Dera Ismail Khan", "district": "Tank", "city": "Tank",
     "lat": 32.2200, "lon": 70.3830, "river": "Gomal (hill torrent)", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 40000, "flood_notes": None},

    # ------------------------------------------------------------- BALOCHISTAN
    {"province": "Balochistan", "division": "Quetta", "district": "Quetta", "city": "Quetta",
     "lat": 30.1798, "lon": 66.9750, "river": None, "terrain": "hill_torrent",
     "historical_flood_prone": False, "population_est": 1200000, "flood_notes": "Urban flash flooding risk during unusually heavy spells; otherwise semi-arid."},

    {"province": "Balochistan", "division": "Sibi", "district": "Sibi", "city": "Sibi",
     "lat": 29.5430, "lon": 67.8770, "river": "Nari", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 95000,
     "flood_notes": "Nari river hill-torrent flooding is a recurring Sibi/Bolan hazard."},

    {"province": "Balochistan", "division": "Nasirabad", "district": "Jaffarabad", "city": "Dera Allah Yar",
     "lat": 28.5100, "lon": 68.5800, "river": "Indus (canal/backwater)", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 60000,
     "flood_notes": "Among the worst-hit low-lying districts in the 2022 floods (near-total submersion)."},

    {"province": "Balochistan", "division": "Nasirabad", "district": "Naseerabad", "city": "Dera Murad Jamali",
     "lat": 28.5000, "lon": 68.2830, "river": "Indus (canal/backwater)", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 55000, "flood_notes": None},

    {"province": "Balochistan", "division": "Kalat", "district": "Khuzdar", "city": "Khuzdar",
     "lat": 27.8000, "lon": 66.6100, "river": None, "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 190000, "flood_notes": None},

    {"province": "Balochistan", "division": "Makran", "district": "Turbat", "city": "Turbat",
     "lat": 26.0040, "lon": 63.0480, "river": "Kech/Dasht", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 250000, "flood_notes": "Rare but very destructive flash floods when Arabian Sea depressions make landfall on the Makran coast."},

    {"province": "Balochistan", "division": "Makran", "district": "Gwadar", "city": "Gwadar",
     "lat": 25.1216, "lon": 62.3254, "river": None, "terrain": "coastal_delta",
     "historical_flood_prone": True, "population_est": 90000,
     "flood_notes": "Cyclone/storm-surge and urban drainage flooding (poor drainage infrastructure in a normally arid climate)."},

    {"province": "Balochistan", "division": "Zhob", "district": "Zhob", "city": "Zhob",
     "lat": 31.3400, "lon": 69.4500, "river": "Zhob", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 55000, "flood_notes": None},

    {"province": "Balochistan", "division": "Zhob", "district": "Loralai", "city": "Loralai",
     "lat": 30.3700, "lon": 68.6000, "river": None, "terrain": "hill_torrent",
     "historical_flood_prone": False, "population_est": 60000, "flood_notes": None},

    {"province": "Balochistan", "division": "Kalat", "district": "Lasbela", "city": "Uthal",
     "lat": 25.8000, "lon": 66.6300, "river": "Porali/Hub", "terrain": "coastal_delta",
     "historical_flood_prone": True, "population_est": 40000, "flood_notes": None},

    # ------------------------------------------------------------ GILGIT-BALTISTAN
    {"province": "Gilgit-Baltistan", "division": "Gilgit", "district": "Gilgit", "city": "Gilgit",
     "lat": 35.9200, "lon": 74.3100, "river": "Gilgit/Indus", "terrain": "glacial_mountain",
     "historical_flood_prone": True, "population_est": 220000,
     "flood_notes": "High glacial melt + GLOF exposure, especially May-August."},

    {"province": "Gilgit-Baltistan", "division": "Baltistan", "district": "Skardu", "city": "Skardu",
     "lat": 35.2900, "lon": 75.6330, "river": "Indus (Shyok/Shigar confluence)", "terrain": "glacial_mountain",
     "historical_flood_prone": True, "population_est": 200000, "flood_notes": None},

    {"province": "Gilgit-Baltistan", "division": "Gilgit", "district": "Hunza", "city": "Karimabad",
     "lat": 36.3200, "lon": 74.6600, "river": "Hunza", "terrain": "glacial_mountain",
     "historical_flood_prone": True, "population_est": 90000,
     "flood_notes": "History of glacial-dam lake events (e.g., Attabad-type blockages) upstream."},

    {"province": "Gilgit-Baltistan", "division": "Baltistan", "district": "Ghanche", "city": "Khaplu",
     "lat": 35.1700, "lon": 76.3300, "river": "Shyok", "terrain": "glacial_mountain",
     "historical_flood_prone": True, "population_est": 30000,
     "flood_notes": "2026 monsoon: flash floods and landslides reported."},

    {"province": "Gilgit-Baltistan", "division": "Diamer", "district": "Diamer", "city": "Chilas",
     "lat": 35.4200, "lon": 74.1000, "river": "Indus", "terrain": "glacial_mountain",
     "historical_flood_prone": True, "population_est": 45000,
     "flood_notes": "2026 monsoon: significant flash flood and landslide damage to roads/bridges."},

    {"province": "Gilgit-Baltistan", "division": "Diamer", "district": "Astore", "city": "Astore",
     "lat": 35.3500, "lon": 74.9000, "river": "Astore", "terrain": "glacial_mountain",
     "historical_flood_prone": True, "population_est": 20000,
     "flood_notes": "2026 monsoon: among the worst-affected upper-north districts."},

    # -------------------------------------------------------- AZAD JAMMU & KASHMIR
    {"province": "Azad Jammu & Kashmir", "division": "Muzaffarabad", "district": "Muzaffarabad", "city": "Muzaffarabad",
     "lat": 34.3700, "lon": 73.4710, "river": "Jhelum/Neelum confluence", "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 150000, "flood_notes": None},

    {"province": "Azad Jammu & Kashmir", "division": "Muzaffarabad", "district": "Neelum", "city": "Athmuqam",
     "lat": 34.5900, "lon": 73.9200, "river": "Neelum", "terrain": "glacial_mountain",
     "historical_flood_prone": True, "population_est": 20000,
     "flood_notes": "2026 monsoon: flash floods and landslide damage reported in Neelum Valley."},

    {"province": "Azad Jammu & Kashmir", "division": "Mirpur", "district": "Mirpur", "city": "Mirpur",
     "lat": 33.1470, "lon": 73.7510, "river": "Jhelum (Mangla Reservoir)", "terrain": "riverine_plain",
     "historical_flood_prone": True, "population_est": 120000,
     "flood_notes": "Downstream flood risk is heavily controlled/mitigated (but also driven) by Mangla Dam release decisions."},

    {"province": "Azad Jammu & Kashmir", "division": "Poonch", "district": "Bagh", "city": "Bagh",
     "lat": 33.9840, "lon": 73.7750, "river": None, "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 30000, "flood_notes": None},

    {"province": "Azad Jammu & Kashmir", "division": "Poonch", "district": "Poonch", "city": "Rawalakot",
     "lat": 33.8560, "lon": 73.7050, "river": None, "terrain": "hill_torrent",
     "historical_flood_prone": True, "population_est": 40000, "flood_notes": None},

    # ------------------------------------------------------- ISLAMABAD CAPITAL TERRITORY
    {"province": "Islamabad Capital Territory", "division": "Islamabad", "district": "Islamabad", "city": "Islamabad",
     "lat": 33.6844, "lon": 73.0479, "river": "Korang/Soan", "terrain": "urban",
     "historical_flood_prone": True, "population_est": 1200000,
     "flood_notes": "Korang river + storm-drain overload risk during intense monsoon spells (paired with Rawalpindi's Nullah Lai)."},
]


def all_provinces():
    return sorted({r["province"] for r in PAKISTAN_REGIONS})


def regions_in_province(province_name: str):
    return [r for r in PAKISTAN_REGIONS if r["province"].lower() == province_name.lower()]


def find_city(city_name: str):
    matches = [r for r in PAKISTAN_REGIONS if r["city"].lower() == city_name.lower()]
    return matches[0] if matches else None


def flood_prone_regions():
    return [r for r in PAKISTAN_REGIONS if r["historical_flood_prone"]]
